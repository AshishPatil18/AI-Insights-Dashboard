# Annual private investment in artificial intelligence - Data package

This data package contains the data that powers the chart ["Annual private investment in artificial intelligence"](https://ourworldindata.org/grapher/private-investment-in-artificial-intelligence-cset?v=1&csvType=full&useColumnShortNames=false&utm_source=chatgpt.com) on the Our World in Data website. It was downloaded on September 11, 2025.

### Active Filters

A filtered subset of the full data was downloaded. The following filters were applied:

## CSV Structure

The high level structure of the CSV file is that each row is an observation for an entity (usually a country or region) and a timepoint (usually a year).

The first two columns in the CSV file are "Entity" and "Code". "Entity" is the name of the entity (e.g. "United States"). "Code" is the OWID internal entity code that we use if the entity is a country or region. For normal countries, this is the same as the [iso alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code of the entity (e.g. "USA") - for non-standard countries like historical countries these are custom codes.

The third column is either "Year" or "Day". If the data is annual, this is "Year" and contains only the year as an integer. If the column is "Day", the column contains a date string in the form "YYYY-MM-DD".

The final column is the data column, which is the time series that powers the chart. If the CSV data is downloaded using the "full data" option, then the column corresponds to the time series below. If the CSV data is downloaded using the "only selected data visible in the chart" option then the data column is transformed depending on the chart type and thus the association with the time series might not be as straightforward.

## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc.. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc..

## About the data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stich together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

## Detailed information about the data


## Estimated investment - All
Only includes private — market investment such as venture capital; excludes all investment in publicly traded companies, such as "Big Tech" firms. This data is expressed in US dollars, adjusted for inflation.
Last updated: April 18, 2025  
Next update: April 2026  
Date range: 2014–2023  
Unit: constant 2021 US$  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Center for Security and Emerging Technology (2025); U.S. Bureau of Labor Statistics (2025) – processed by Our World in Data

#### Full citation
Center for Security and Emerging Technology (2025); U.S. Bureau of Labor Statistics (2025) – processed by Our World in Data. “Estimated investment - All” [dataset]. Center for Security and Emerging Technology, “Country Activity Tracker: Artificial Intelligence”; U.S. Bureau of Labor Statistics, “US consumer prices” [original data].
Source: Center for Security and Emerging Technology (2025), U.S. Bureau of Labor Statistics (2025) – processed by Our World In Data

### What you should know about this data
* The data likely underestimates total global AI investment, as it only captures certain types of private equity transactions, excluding other significant channels and categories of AI — related spending.
* The dataset only covers private — market investment such as venture capital. It excludes non — equity financing, such as debt and grants, and publicly traded companies, including major Big Tech firms. As a result, significant investments from public companies, corporate R&D, government funding, and broader infrastructure costs (like data centers and hardware) are not captured, limiting the data's coverage of global AI investments.
* The data's "World" aggregate reflects the total investment represented in the data, but may not represent global AI efforts comprehensively, especially in countries not included in the data.
* Companies are classified as AI — related based on keyword and industry tags, potentially including firms not traditionally seen as AI — focused while missing others due to definitional differences.
* Many investment values are undisclosed, so the source relies on median values from similar transactions, introducing some uncertainty. Additionally, investment origin is attributed to company headquarters, which may overlook cross — border structures or varied investor origins.
* One — time events, such as large acquisitions, can distort yearly figures, while broader economic factors like interest rates and market sentiment can influence investment trends independently of AI — specific developments.

### Sources

#### Center for Security and Emerging Technology – Country Activity Tracker: Artificial Intelligence
Retrieved on: 2025-04-18  
Retrieved from: https://cat.eto.tech/  

#### U.S. Bureau of Labor Statistics – US consumer prices
Retrieved on: 2025-04-12  
Retrieved from: https://www.bls.gov/data/tools.htm  

#### Notes on our processing step for this indicator
- Reporting a time series of AI investments in nominal prices would make it difficult to compare observations across time. To make these comparisons possible, one has to take into account that prices change (inflation).
- It is not obvious how to adjust this time series for inflation, and our team discussed the best solutions at our disposal.
- It would be straightforward to adjust the time series for price changes if we knew the prices of the specific goods and services purchased through these investments. This would make it possible to calculate a volume measure of AI investments and tell us how much these investments bought. But such a metric is not available. While a comprehensive price index is not available, we know that the cost of some crucial AI technology has fallen rapidly in price.
- In the absence of a comprehensive price index that captures the price of AI — specific goods and services, one has to rely on one of the available metrics for the price of a bundle of goods and services. Ultimately, we decided to use the US Consumer Price Index (CPI).
- The US CPI does not provide us with a volume measure of AI goods and services, but it does capture the opportunity costs of these investments. The inflation adjustment of this time series of AI investments, therefore, lets us understand the size of these investments relative to whatever else these sums of money could have purchased.
- World aggregate does not include data for Micronesia, Tonga, Samoa, Kiribati, Fiji, Papua New Guinea, Palau, Tuvalu, Bermuda, Armenia, Belarus, Georgia, Gibraltar, Jersey, Kosovo, Moldova, Isle of Man, Iceland, Albania, Andorra, Bosnia and Herzegovina, Malta, Montenegro, San Marino, North Macedonia, Liechtenstein, Monaco, Vatican City, Guernsey, Afghanistan, Kyrgyzstan, Bahrain, Laos, Bangladesh, Lebanon, Bhutan, Maldives, Cambodia, Syria, Tajikistan, Cyprus, Mongolia, North Korea, Myanmar, Timor-Leste, Nepal, Turkmenistan, Pakistan, Palestine, Iraq, United Arab Emirates, Uzbekistan, Kazakhstan, Qatar, Vietnam, Yemen, Kuwait, Algeria, Cape Verde, Equatorial Guinea, Swaziland, Namibia, Central African Republic (the), Angola, Ethiopia, Niger, Benin, Gabon, Nigeria, Botswana, Gambia, Rwanda, Burkina Faso, Ghana, São Tomé and Príncipe, Burundi, Guinea, Senegal, Guinea-Bissau, Seychelles, Cameroon, Sierra Leone, Lesotho, Somalia, Chad, Liberia, Libya, South Sudan, Congo, Madagascar, Sudan, Côte d'Ivoire, Malawi, Togo, Mali, Djibouti, Mauritania, Uganda, Egypt, Mauritius, Tanzania, Zambia, Eritrea, Mozambique, Zimbabwe, Comoros, Antigua and Barbuda, Bolivia, Suriname, Nicaragua, Dominican Republic, Bahamas, Ecuador, Paraguay, Barbados, Saint Vincent and the Grenadines, El Salvador, Belize, Grenada, Saint Kitts and Nevis, Guatemala, Guyana, Haiti, Honduras, Trinidad and Tobago, Jamaica, Venezuela, Puerto Rico, Cayman Islands (the), Turks and Caicos Islands, Saint Lucia, and Dominica.


    